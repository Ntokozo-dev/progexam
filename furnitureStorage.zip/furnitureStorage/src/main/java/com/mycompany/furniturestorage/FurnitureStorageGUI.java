/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.furniturestorage;
import javax.swing.*;
import java.awt.*;
import java.io.*;

/**
 *
 * @author ntokozomtsali
 */


public class FurnitureStorageGUI extends JFrame {
    
    private JTextField customerNameField;
    private JTextField priceField;
    private JComboBox<Integer> durationCombo;
    private JButton processButton;
    private JButton saveButton;
    
    /**
     * Constructor - Initializes the GUI
     */
    public FurnitureStorageGUI () {
        super("Furniture Storage");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 350);
        setLocationRelativeTo(null);
        
        createMenuBar();
        buildUI();
    }
    
    /**
     * Creates the menu bar
     */
    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        
        // File menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);
        
        // Tools menu
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem saveItem = new JMenuItem("Save");
        
        processItem.addActionListener(e -> processCustomerData());
        saveItem.addActionListener(e -> saveData());
        
        toolsMenu.add(processItem);
        toolsMenu.add(saveItem);
        
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        
        setJMenuBar(menuBar);
    }
    
    /**
     * Builds all GUI components
     */
    private void buildUI() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        
        // Customer Name
        JLabel nameLabel = new JLabel("Customer Name:");
        customerNameField = new JTextField();
        formPanel.add(nameLabel);
        formPanel.add(customerNameField);
        
        // Price
        JLabel priceLabel = new JLabel("Price (R):");
        priceField = new JTextField();
        formPanel.add(priceLabel);
        formPanel.add(priceField);
        
        // Duration
        JLabel durationLabel = new JLabel("Duration (Months):");
        durationCombo = new JComboBox<>(new Integer[]{3, 6, 12});
        durationCombo.setSelectedIndex(0);
        formPanel.add(durationLabel);
        formPanel.add(durationCombo);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        processButton = new JButton("PROCESS");
        processButton.addActionListener(e -> processCustomerData());
        buttonPanel.add(processButton);
        
        saveButton = new JButton("SAVE");
        saveButton.addActionListener(e -> saveData());
        buttonPanel.add(saveButton);
        
        // Version label
        JLabel versionLabel = new JLabel("Furniture Storage v1.0");
        versionLabel.setFont(versionLabel.getFont().deriveFont(Font.PLAIN, 10f));
        versionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        mainPanel.add(versionLabel, BorderLayout.NORTH);
        
        add(mainPanel);
    }
    
    /**
     * Processes customer data and displays results
     */
    private void processCustomerData() {
        try {
            String customerName = customerNameField.getText();
            double price = Double.parseDouble(priceField.getText());
            int duration = (int) durationCombo.getSelectedItem();
            
            // Validation
            if (customerName.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Customer name cannot be empty!",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (price <= 0) {
                JOptionPane.showMessageDialog(this, 
                    "Price must be greater than 0!",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Calculate VAT and Total
            double vat = price * 0.15;
            double total = (price + vat) * duration;
            
            // Display results
            String message = "=== FURNITURE STORAGE RECEIPT ===\n\n" +
                           "Customer Name: " + customerName + "\n" +
                           "Storage Duration: " + duration + " months\n" +
                           "Price: R " + String.format("%.2f", price) + "\n" +
                           "VAT (15%): R " + String.format("%.2f", vat) + "\n" +
                           "TOTAL: R " + String.format("%.2f", total) + "\n\n" +
                           "===================================";
            
            JOptionPane.showMessageDialog(this, message, 
                "Transaction Summary", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, 
                "Please enter a valid price!",
                "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Saves transaction data to file
     */
    private void saveData() {
        try {
            String customerName = customerNameField.getText();
            double price = Double.parseDouble(priceField.getText());
            int duration = (int) durationCombo.getSelectedItem();
            
            if (customerName.isEmpty() || price <= 0) {
                JOptionPane.showMessageDialog(this, 
                    "Please complete the form first!",
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            double vat = price * 0.15;
            double total = (price + vat) * duration;
            
            try (PrintWriter out = new PrintWriter(new FileWriter("data.txt", true))) {
                out.println("DATA LOG");
                out.println(".............................");
                out.println("Customer Name: " + customerName);
                out.println("Storage Duration: " + duration + " months");
                out.println("Price: R " + String.format("%.2f", price));
                out.println("VAT: R " + String.format("%.2f", vat));
                out.println("TOTAL: R " + String.format("%.2f", total));
                out.println(".............................");
                out.println();
            }
            
            JOptionPane.showMessageDialog(this, 
                "Data saved to data.txt successfully!",
                "Success", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, 
                "Please enter a valid price!",
                "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error saving file: " + ex.getMessage(),
                "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Main method - Entry point
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FurnitureStorageGUI app = new FurnitureStorageGUI();
            app.setVisible(true);
        });
    }
}
