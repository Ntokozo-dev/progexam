/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.furniturestorage;

/**
 *
 * @author ntokozomtsali
 */

/**
 * Calculations Class
 * 
 * Implements the ICalculations interface to perform
 * furniture storage calculations (VAT and Total).
 * 
 * This class separates business logic from the GUI,
 * making it testable and reusable.
 */
public class Calculations implements ICalculations {
    
    // Private fields to store calculation values
    private double price;        // Storage price
    private int duration;        // Storage duration in months
    private double vat;          // Calculated VAT (15%)
    private double total;        // Calculated total
    
    /**
     * Constructor - Initializes calculation values
     * 
     * @param price storage price
     * @param duration storage duration in months
     */
    public Calculations(double price, int duration) {
        this.price = price;
        this.duration = duration;
        this.vat = calculateVAT();
        this.total = calculateTotal();
    }
    
    /**
     * Calculates VAT (15% of price)
     * 
     * Formula: VAT = Price × 0.15
     * 
     * @return VAT amount
     */
    private double calculateVAT() {
        return price * 0.15;
    }
    
    /**
     * Calculates total cost
     * @return total cost
     */
    private double calculateTotal() {
        return (price + vat) * duration;
    }
    
    /**
     * Returns the calculated VAT amount
     * 
     * Implements the ICalculations interface method
     * 
     * @return VAT value (15% of price)
     */
    @Override
    public double GetVat() {
        return vat;
    }
    
    /**
     * Returns the calculated total cost
     * 
     * Implements the ICalculations interface method
     * 
     * @return total cost ((price + VAT) × duration)
     */
    @Override
    public double GetTotal() {
        return total;
    }
    
    /**
     * Returns the price
     * 
     * @return price value
     */
    public double getPrice() {
        return price;
    }
    
    /**
     * Returns the duration
     * 
     * @return duration in months
     */
    public int getDuration() {
        return duration;
    }
}
 
