/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.furniturestorage;

/**
 *
 * @author ntokozomtsali
 */
public class Data {
  private  String customerName;
  private String storagePrice;
  private String storageDuration;
  private String vatPercentage;
  //constructor
  public Data (){
     this.customerName = "";
        this.storagePrice = "";
        this.storageDuration = "";
        this.vatPercentage = "";  
  }
    
  public String getCustomerName(){
      return customerName;
  } 
  public String getStoragePrice(){
      return storagePrice;
  }
  public String getStorageDuration(){
      return storageDuration;
  }
  public String getPercentage(){
     return vatPercentage;  
  }
   public void setCustomerName (String customerName) {
      this.customerName = customerName;  
  } 
  public void setStoragePrice (String storagePrice){
      this .storagePrice = storagePrice;
  }
  public void setStorageDuration (String storageDuration){
      this .storageDuration = storageDuration;
  }
  public void setVatPercentage (String VATPercentage){
      this .vatPercentage = vatPercentage;
}
}

