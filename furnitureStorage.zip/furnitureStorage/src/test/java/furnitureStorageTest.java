/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


import com.mycompany.furniturestorage.FurnitureStorageGUI;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ntokozomtsali
 */
public class furnitureStorageTest {
    
  @Test
  //set up data to be tested
  public void GetVat_WithValidData_ReturnsCorrectValue(){
        //  Set up test data
        double price = 1000.0;
        double expectedVAT = 150.0;  // 1000 × 0.15
        
        // Calculate VAT
        double calculatedVAT = price * 0.15;
        
        // ASSERT: Verify VAT is correct
        assertEquals(expectedVAT, calculatedVAT, 0.01,
                     "VAT should be 150.0 (1000 × 0.15)");
    }
    
    @Test
    public void TestTotalCalculation_3Months() {
        // ARRANGE: Set up test data
        double price = 1000.0;
        double vat = 150.0;
        int duration = 3;
        double expectedTotal = 3450.0;  // (1000 + 150) × 3
        
        // ACT: Calculate total
        double calculatedTotal = (price + vat) * duration;
        
        // ASSERT: Verify total is correct
        assertEquals(expectedTotal, calculatedTotal, 0.01,
                     "Total should be 3450.0 " +
                     "((1000 + 150) × 3)");
    }
    

    @Test
    public void TestTotalCalculation_6Months() {
        // ARRANGE: Set up test data for 6 months
        double price = 1000.0;
        double vat = 150.0;
        int duration = 6;
        double expectedTotal = 6900.0;  // (1000 + 150) × 6
        
        // ACT: Calculate total
        double calculatedTotal = (price + vat) * duration;
        
        // ASSERT: Verify total is correct
        assertEquals(expectedTotal, calculatedTotal, 0.01,
                     "Total for 6 months should be 6900.0 " +
                     "((1000 + 150) × 6)");
    }
    
  
    @Test
    public void TestTotalCalculation_12Months() {
        // Set up test data for 12 months
        double price = 1000.0;
        double vat = 150.0;
        int duration = 12;
        double expectedTotal = 13800.0;  // (1000 + 150) × 12
        
        // Calculate total
        double calculatedTotal = (price + vat) * duration;
        
        //Verify total is correct
        assertEquals(expectedTotal, calculatedTotal, 0.01,
                     "Total for 12 months should be 13800.0 " +
                     "((1000 + 150) × 12)");
    }
    
}