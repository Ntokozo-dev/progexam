/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.furniturestoragereport;

/**
 *
 * @author ntokozomtsali
 */
public interface IFurnitureStorage {
    int GetTotalCustomers();
    double GetAverageCustomer();
    String GetMostPopularTown();
    String GetLeastPopularTown();
            
}
