/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.furniturestoragereport;

/**
 *
 * @author ntokozomtsali
 */
public class FurnitureStorageReport {
 public static void main(String[] args) {
 int[][] totalCustomers = {
 {90, 15, 50},// Year 1 sales for Q1, Q2, Q3
 {125, 55, 91}// Year 2 sales for Q1, Q2, Q3
 };

        // Create an instance of ProductSales to perform calculations
 TotalCustomers ts = new TotalCustomers();
// Call methods to calculate sales statistics
 int totalSales = ts.TotSales(totalCustomers);
 double averageSales = ts.AverageSales(totalCustomers);
 int maximumSales = ts.MaxSale(totalCustomers);
 int minimumSales = ts.MinSale(totalCustomers);

 // Print report (similar formatting to the sample)
 System.out.println("FURNITURE STORAGE REPORT - 2025");
 System.out.println("-------------------------------");
 System.out.println("Total customers: " + totalSales);
 System.out.println("Average customers: " + averageSales);
 System.out.println("Town with most customers: " + maximumSales);
 System.out.println("Town with least customers: " + minimumSales);

 }
 }
    