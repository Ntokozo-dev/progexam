/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.furniturestoragereport;

/**
 *
 * @author ntokozomtsali
 */

// Main class that uses FurnitureStorage to analyze customer data and displays a formatted report.

public class PrintFurnitureReport {
    
    /**
     * Main method - Entry point of the application
     * 
     * Creates test data, analyzes it, and prints a report
     * 
     */
    public static void main(String[] args) {
        // Create customer data: 2D array
        // Rows = towns, Columns = time periods (months/quarters)
        int[][] totalCustomers = {
            {90, 15, 50},      // Town 0: Pretoria
            {125, 55, 91}      // Town 1: Johannesburg
        };
        
        // Create FurnitureStorage instance with the data
        FurnitureStorage storage = new FurnitureStorage(totalCustomers);
        
        // Get analysis results
        int totalCustomers = storage.GetTotalCustomers();
        double averageCustomers = storage.GetAverageCustomer();
        String mostPopularTown = storage.GetMostPopularTown();
        String leastPopularTown = storage.GetLeastPopularTown();
        
        // Print formatted report
        System.out.println("===========================================");
        System.out.println("    FURNITURE STORAGE CUSTOMER REPORT");
        System.out.println("===========================================");
        System.out.println();
        System.out.println("Total Customers:           " + totalCustomers);
        System.out.println("Average Customers/Town:    " + 
                          String.format("%.2f", averageCustomers));
        System.out.println("Most Popular Town:         " + mostPopularTown);
        System.out.println("Least Popular Town:        " + leastPopularTown);
        System.out.println();
        System.out.println("===========================================");
    }
}