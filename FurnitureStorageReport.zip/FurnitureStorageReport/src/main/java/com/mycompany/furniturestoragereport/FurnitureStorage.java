/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.furniturestoragereport;

/**
 *
 * @author ntokozomtsali


/**
 * FurnitureStorage Class
 * 
 * Implements the IFurnitureStorage interface to analyze
 * furniture storage customer data across different towns.
 */
public class FurnitureStorage implements IFurnitureStorage {
    
    private int[][] customerData;
    
    /**
     * Constructor - Initializes with customer data
     * 
     * @param customerData 2D array of customer counts
     */
    public FurnitureStorage(int[][] customerData) {
        this.customerData = customerData;
    }
    
    /**
     * Calculates total number of customers across all towns
     * 
     * @return total number of customers
     */
    @Override
    public int GetTotalCustomers() {
        int total = 0;
        
        for (int[] townRow : customerData) {
            for (int customers : townRow) {
                total += customers;
            }
        }
        
        return total;
    }
    
    /**
     * Calculates average customers per town
     * 
     * @return average customers per town
     */
    @Override
    public double GetAverageCustomer() {
        int total = GetTotalCustomers();
        int townCount = customerData.length;
        
        if (townCount == 0) {
            return 0.0;
        }
        
        return (double) total / townCount;
    }
    
    /**
     * Finds the town with the most customers
     * 
     * @return name of town with most customers
     */
    @Override
    public String GetMostPopularTown() {
        String[] townNames = {"Pretoria", "Johannesburg", "Cape Town"};
        
        int maxCustomers = 0;
        int maxTownIndex = 0;
        
        for (int i = 0; i < customerData.length; i++) {
            int townTotal = 0;
            for (int customers : customerData[i]) {
                townTotal += customers;
            }
            
            if (townTotal > maxCustomers) {
                maxCustomers = townTotal;
                maxTownIndex = i;
            }
        }
        
        return townNames[maxTownIndex];
    }
    
    /**
     * Finds the town with the least customers
     * 
     * @return name of town with least customers
     */
    @Override
    public String GetLeastPopularTown() {
        String[] townNames = {"Pretoria", "Johannesburg", "Cape Town"};
        
        int minCustomers = Integer.MAX_VALUE;
        int minTownIndex = 0;
        
        for (int i = 0; i < customerData.length; i++) {
            int townTotal = 0;
            for (int customers : customerData[i]) {
                townTotal += customers;
            }
            
            if (townTotal < minCustomers) {
                minCustomers = townTotal;
                minTownIndex = i;
            }
        }
        
        return townNames[minTownIndex];
    }
}